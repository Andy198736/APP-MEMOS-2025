function formatDate(date) {
    try {
        if (!date) return '';
        
        // Adjust for timezone offset
        const d = new Date(date);
        const userTimezoneOffset = d.getTimezoneOffset() * 60000;
        const adjustedDate = new Date(d.getTime() + userTimezoneOffset);
        
        return adjustedDate.toLocaleDateString('es-CL', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit'
        });
    } catch (error) {
        console.error('Date formatting error:', error);
        reportError(error);
        return '';
    }
}

function getDaysUntil(date) {
    try {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const targetDate = new Date(date);
        // Adjust for timezone offset
        const userTimezoneOffset = targetDate.getTimezoneOffset() * 60000;
        const adjustedDate = new Date(targetDate.getTime() + userTimezoneOffset);
        adjustedDate.setHours(23, 59, 59, 999);
        const diffTime = adjustedDate - today;
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        return diffDays;
    } catch (error) {
        console.error('Date calculation error:', error);
        reportError(error);
        return 0;
    }
}

function getMemoStatus(endDate) {
    try {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const end = new Date(endDate);
        // Adjust for timezone offset
        const userTimezoneOffset = end.getTimezoneOffset() * 60000;
        const adjustedDate = new Date(end.getTime() + userTimezoneOffset);
        adjustedDate.setHours(23, 59, 59, 999);

        if (adjustedDate < today) {
            return { text: 'Vencido', color: 'bg-red-100 text-red-800' };
        } else if (isSameDay(adjustedDate, today)) {
            return { text: 'Vence Hoy', color: 'bg-yellow-100 text-yellow-800' };
        } else if (adjustedDate <= addDays(today, 7)) {
            return { text: 'Por Vencer', color: 'bg-yellow-100 text-yellow-800' };
        } else {
            return { text: 'Vigente', color: 'bg-green-100 text-green-800' };
        }
    } catch (error) {
        console.error('Status calculation error:', error);
        reportError(error);
        return { text: 'Error', color: 'bg-gray-100 text-gray-800' };
    }
}

function isSameDay(date1, date2) {
    try {
        // Adjust both dates for timezone
        const d1 = new Date(date1);
        const d2 = new Date(date2);
        const userTimezoneOffset = d1.getTimezoneOffset() * 60000;
        const adjustedDate1 = new Date(d1.getTime() + userTimezoneOffset);
        const adjustedDate2 = new Date(d2.getTime() + userTimezoneOffset);
        
        return adjustedDate1.getFullYear() === adjustedDate2.getFullYear() &&
            adjustedDate1.getMonth() === adjustedDate2.getMonth() &&
            adjustedDate1.getDate() === adjustedDate2.getDate();
    } catch (error) {
        console.error('Date comparison error:', error);
        reportError(error);
        return false;
    }
}

function addDays(date, days) {
    try {
        const result = new Date(date);
        // Adjust for timezone offset
        const userTimezoneOffset = result.getTimezoneOffset() * 60000;
        const adjustedDate = new Date(result.getTime() + userTimezoneOffset);
        adjustedDate.setDate(adjustedDate.getDate() + days);
        adjustedDate.setHours(23, 59, 59, 999);
        return adjustedDate;
    } catch (error) {
        console.error('Date addition error:', error);
        reportError(error);
        return date;
    }
}

function isExpiringToday(endDate) {
    try {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const end = new Date(endDate);
        // Adjust for timezone offset
        const userTimezoneOffset = end.getTimezoneOffset() * 60000;
        const adjustedDate = new Date(end.getTime() + userTimezoneOffset);
        adjustedDate.setHours(23, 59, 59, 999);
        return isSameDay(adjustedDate, today);
    } catch (error) {
        console.error('Expiring check error:', error);
        reportError(error);
        return false;
    }
}

function adjustForTimezone(date) {
    try {
        if (!date) return null;
        const d = new Date(date);
        const userTimezoneOffset = d.getTimezoneOffset() * 60000;
        return new Date(d.getTime() + userTimezoneOffset);
    } catch (error) {
        console.error('Timezone adjustment error:', error);
        reportError(error);
        return date;
    }
}
