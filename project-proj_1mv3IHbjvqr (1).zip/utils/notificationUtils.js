function playNotificationSound() {
    try {
        const audio = document.getElementById('notificationSound');
        if (audio) {
            audio.play().catch(error => {
                console.error('Error playing notification sound:', error);
            });
        }
    } catch (error) {
        console.error('Notification sound error:', error);
        reportError(error);
    }
}

function cleanupExpiredNotifications() {
    try {
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        trickleListObjects('memo_notification', 1000, true).then(result => {
            const notifications = result.items || [];
            notifications.forEach(notification => {
                const notifDate = new Date(notification.objectData.createdAt);
                notifDate.setHours(0, 0, 0, 0);
                
                if (notifDate < today) {
                    trickleDeleteObject('memo_notification', notification.objectId)
                        .catch(error => console.error('Error deleting notification:', error));
                }
            });
        });
    } catch (error) {
        console.error('Cleanup notifications error:', error);
        reportError(error);
    }
}
