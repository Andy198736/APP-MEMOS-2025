function validateDates(startDate, endDate) {
    try {
        if (!startDate) return 'La fecha de inicio es requerida';
        if (!endDate) return 'La fecha de término es requerida';
        
        const start = new Date(startDate);
        const userTimezoneOffset = start.getTimezoneOffset() * 60000;
        const adjustedStart = new Date(start.getTime() + userTimezoneOffset);
        adjustedStart.setHours(0, 0, 0, 0);

        const end = new Date(endDate);
        const adjustedEnd = new Date(end.getTime() + userTimezoneOffset);
        adjustedEnd.setHours(23, 59, 59, 999);

        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        if (adjustedStart > adjustedEnd) return 'La fecha de inicio no puede ser posterior a la fecha de término';
        
        return null;
    } catch (error) {
        console.error('Validation error:', error);
        reportError(error);
        return 'Error de validación';
    }
}

function validateMemoNumber(memoNumber) {
    try {
        if (!memoNumber) return 'El número de memo es requerido';
        
        // Allow "CORREO" and "WHATSAPP" as special cases
        if (memoNumber.toUpperCase() === 'CORREO' || memoNumber.toUpperCase() === 'WHATSAPP') {
            return null;
        }
        
        // For other cases, check if it contains only letters and numbers
        if (!/^[A-Za-z0-9]*$/.test(memoNumber)) {
            return 'El número de memo solo puede contener letras y números';
        }
        
        return null;
    } catch (error) {
        console.error('Memo number validation error:', error);
        reportError(error);
        return 'Error de validación';
    }
}
