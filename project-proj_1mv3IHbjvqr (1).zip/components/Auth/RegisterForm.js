function RegisterForm({ onRegister, onCancel }) {
    try {
        const [username, setUsername] = React.useState('');
        const [password, setPassword] = React.useState('');
        const [confirmPassword, setConfirmPassword] = React.useState('');
        const [error, setError] = React.useState('');
        const [loading, setLoading] = React.useState(false);

        const handleSubmit = async (e) => {
            e.preventDefault();
            setLoading(true);
            setError('');

            try {
                // Validate inputs
                const usernameError = validateUsername(username);
                if (usernameError) {
                    setError(usernameError);
                    return;
                }

                const passwordError = validatePassword(password);
                if (passwordError) {
                    setError(passwordError);
                    return;
                }

                if (password !== confirmPassword) {
                    setError('Las contraseñas no coinciden');
                    return;
                }

                // Check if username already exists
                const result = await trickleListObjects('user', 100, true);
                const users = result.items || [];
                if (users.some(u => u.objectData.username.toLowerCase() === username.toLowerCase())) {
                    setError('El usuario ya existe');
                    return;
                }

                // Create new user
                const newUser = await trickleCreateObject('user', {
                    username: username.toLowerCase(),
                    password: password,
                    isAdmin: false,
                    createdAt: new Date().toISOString()
                });

                // Create audit log
                await trickleCreateObject('audit', {
                    action: 'create_user',
                    userId: newUser.objectId,
                    username: username,
                    timestamp: new Date().toISOString(),
                    details: `New user ${username} created`
                });

                console.log('User created successfully:', newUser);
                onRegister(newUser);
            } catch (error) {
                console.error('Registration error:', error);
                setError('Error al registrar usuario. Por favor intente nuevamente.');
            } finally {
                setLoading(false);
            }
        };

        return (
            <div className="auth-container" data-name="register-container">
                <div className="auth-card">
                    <h2 className="auth-title">Registrar Usuario</h2>
                    {error && (
                        <Alert 
                            type="error" 
                            message={error} 
                            onClose={() => setError('')}
                        />
                    )}
                    <form onSubmit={handleSubmit} className="auth-form" data-name="register-form">
                        <div className="auth-input-group">
                            <label className="auth-label" htmlFor="username">
                                Usuario
                            </label>
                            <input
                                type="text"
                                id="username"
                                className="auth-input"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                required
                                disabled={loading}
                                data-name="username-input"
                            />
                        </div>
                        <div className="auth-input-group">
                            <label className="auth-label" htmlFor="password">
                                Contraseña
                            </label>
                            <input
                                type="password"
                                id="password"
                                className="auth-input"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                                disabled={loading}
                                data-name="password-input"
                            />
                        </div>
                        <div className="auth-input-group">
                            <label className="auth-label" htmlFor="confirm-password">
                                Confirmar Contraseña
                            </label>
                            <input
                                type="password"
                                id="confirm-password"
                                className="auth-input"
                                value={confirmPassword}
                                onChange={(e) => setConfirmPassword(e.target.value)}
                                required
                                disabled={loading}
                                data-name="confirm-password-input"
                            />
                        </div>
                        <div className="flex gap-2">
                            <button
                                type="button"
                                onClick={onCancel}
                                className="flex-1 bg-gray-500 text-white py-2 px-4 rounded-md hover:bg-gray-600 disabled:opacity-50"
                                disabled={loading}
                                data-name="cancel-button"
                            >
                                Cancelar
                            </button>
                            <button
                                type="submit"
                                className="flex-1 bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600 disabled:opacity-50"
                                disabled={loading}
                                data-name="submit-button"
                            >
                                {loading ? (
                                    <span>
                                        <i className="fas fa-spinner fa-spin mr-2"></i>
                                        Registrando...
                                    </span>
                                ) : (
                                    'Registrar'
                                )}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        );
    } catch (error) {
        console.error('RegisterForm error:', error);
        reportError(error);
        return null;
    }
}
