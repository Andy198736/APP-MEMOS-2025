function LoginForm({ onLogin }) {
    try {
        const [username, setUsername] = React.useState('');
        const [password, setPassword] = React.useState('');
        const [error, setError] = React.useState('');
        const [loading, setLoading] = React.useState(false);

        const handleSubmit = async (e) => {
            e.preventDefault();
            setLoading(true);
            setError('');

            try {
                // Check for admin credentials first
                if (username.toLowerCase() === 'admin' && password === '123') {
                    onLogin({
                        objectId: 'admin',
                        objectData: {
                            username: 'admin',
                            isAdmin: true
                        }
                    });
                    return;
                }

                // Check regular user credentials
                const result = await trickleListObjects('user', 100, true);
                const users = result.items || [];
                
                // Debug log to check users
                console.log('Found users:', users);

                const user = users.find(u => 
                    u.objectData.username.toLowerCase() === username.toLowerCase() &&
                    u.objectData.password === password
                );

                if (user) {
                    // Create login audit
                    try {
                        await trickleCreateObject('audit', {
                            action: 'user_login',
                            userId: user.objectId,
                            username: user.objectData.username,
                            timestamp: new Date().toISOString(),
                            details: `User ${username} logged in successfully`
                        });
                    } catch (auditError) {
                        console.error('Audit log error:', auditError);
                        // Don't block login if audit fails
                    }

                    onLogin({
                        ...user,
                        objectData: {
                            ...user.objectData,
                            isAdmin: false
                        }
                    });
                } else {
                    setError('Usuario o contraseña incorrectos');
                    console.log('Login failed for:', username);
                }
            } catch (error) {
                console.error('Login error:', error);
                setError('Error al iniciar sesión. Por favor intente nuevamente.');
            } finally {
                setLoading(false);
            }
        };

        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-100" data-name="login-container">
                <div className="bg-white p-8 rounded-lg shadow-md w-96" data-name="login-form-container">
                    <h2 className="text-2xl font-bold mb-6 text-center text-gray-800" data-name="login-title">
                        Iniciar Sesión
                    </h2>
                    {error && (
                        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4" data-name="login-error">
                            {error}
                        </div>
                    )}
                    <form onSubmit={handleSubmit} data-name="login-form">
                        <div className="mb-4">
                            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="username">
                                Usuario
                            </label>
                            <input
                                type="text"
                                id="username"
                                className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                required
                                disabled={loading}
                                data-name="username-input"
                            />
                        </div>
                        <div className="mb-6">
                            <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="password">
                                Contraseña
                            </label>
                            <input
                                type="password"
                                id="password"
                                className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                                disabled={loading}
                                data-name="password-input"
                            />
                        </div>
                        <button
                            type="submit"
                            className="w-full bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600 transition-colors disabled:opacity-50"
                            disabled={loading}
                            data-name="login-button"
                        >
                            {loading ? (
                                <span>
                                    <i className="fas fa-spinner fa-spin mr-2"></i>
                                    Ingresando...
                                </span>
                            ) : (
                                'Ingresar'
                            )}
                        </button>
                    </form>
                </div>
            </div>
        );
    } catch (error) {
        console.error('LoginForm error:', error);
        reportError(error);
        return null;
    }
}
