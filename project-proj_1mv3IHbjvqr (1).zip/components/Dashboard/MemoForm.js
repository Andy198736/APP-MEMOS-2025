function MemoForm({ onSave, editingMemo = null }) {
    try {
        const [memoNumber, setMemoNumber] = React.useState(editingMemo?.objectData.memoNumber || '');
        const [truckPlate, setTruckPlate] = React.useState(editingMemo?.objectData.truckPlate || '');
        const [truckNumber, setTruckNumber] = React.useState(editingMemo?.objectData.truckNumber || '');
        const [commune, setCommune] = React.useState(editingMemo?.objectData.commune || '');
        const [startDate, setStartDate] = React.useState(editingMemo?.objectData.startDate || '');
        const [endDate, setEndDate] = React.useState(editingMemo?.objectData.endDate || '');
        const [observation, setObservation] = React.useState(editingMemo?.objectData.observation || '');
        const [loading, setLoading] = React.useState(false);
        const [error, setError] = React.useState('');
        const [success, setSuccess] = React.useState('');

        const handleMemoNumberChange = (e) => {
            const value = e.target.value;
            // Allow any input for memo number, it will be validated on submit
            setMemoNumber(value.toUpperCase());
        };

        const handleTruckPlateChange = (e) => {
            const value = e.target.value;
            // Only allow letters and numbers
            if (/^[A-Za-z0-9]*$/.test(value)) {
                setTruckPlate(value.toUpperCase());
            }
        };

        const handleTruckNumberChange = (e) => {
            const value = e.target.value;
            // Only allow letters and numbers
            if (/^[A-Za-z0-9]*$/.test(value)) {
                setTruckNumber(value.toUpperCase());
            }
        };

        const handleSubmit = async (e) => {
            e.preventDefault();
            setLoading(true);
            setError('');
            setSuccess('');

            try {
                // Basic validation
                if (!memoNumber || !truckPlate || !truckNumber || !commune || !startDate || !endDate) {
                    setError('Todos los campos son requeridos');
                    setLoading(false);
                    return;
                }

                // Validate memo number
                const memoNumberError = validateMemoNumber(memoNumber);
                if (memoNumberError) {
                    setError(memoNumberError);
                    setLoading(false);
                    return;
                }

                // Validate dates
                const dateError = validateDates(startDate, endDate);
                if (dateError) {
                    setError(dateError);
                    setLoading(false);
                    return;
                }

                // Prepare memo data
                const memoData = {
                    memoNumber: memoNumber.toUpperCase(),
                    truckPlate: truckPlate.toUpperCase(),
                    truckNumber: truckNumber.toUpperCase(),
                    commune,
                    startDate,
                    endDate,
                    observation: observation || '',
                    createdAt: new Date().toISOString()
                };

                // Save or update memo
                if (editingMemo) {
                    await trickleUpdateObject('memo', editingMemo.objectId, {
                        ...memoData,
                        createdAt: editingMemo.objectData.createdAt,
                        lastModifiedAt: new Date().toISOString()
                    });
                    setSuccess('Memorándum actualizado exitosamente');
                } else {
                    await trickleCreateObject('memo', memoData);
                    setSuccess('Memorándum guardado exitosamente');
                }

                playNotificationSound();

                // Clear form after successful save
                setTimeout(() => {
                    if (!editingMemo) {
                        clearForm();
                    }
                    onSave();
                }, 2000);
            } catch (error) {
                console.error('Error saving memo:', error);
                setError('Error al guardar el memorándum. Por favor intente nuevamente.');
            } finally {
                setLoading(false);
            }
        };

        const clearForm = () => {
            setMemoNumber('');
            setTruckPlate('');
            setTruckNumber('');
            setCommune('');
            setStartDate('');
            setEndDate('');
            setObservation('');
            setError('');
            setSuccess('');
        };

        // Rest of the component remains the same...
        return (
            <div className="bg-white p-6 rounded-lg shadow-md" data-name="memo-form-container">
                <h2 className="text-xl font-bold mb-4" data-name="memo-form-title">
                    {editingMemo ? 'Editar Memorándum' : 'Nuevo Memorándum'}
                </h2>

                {error && (
                    <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4" data-name="error-message">
                        {error}
                    </div>
                )}

                {success && (
                    <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4" data-name="success-message">
                        {success}
                    </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-4" data-name="memo-form">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-gray-700 text-sm font-bold mb-2">
                                N° Memo
                                <span className="text-xs text-gray-500 ml-1">(letras y números, CORREO, WHATSAPP)</span>
                            </label>
                            <input
                                type="text"
                                className="w-full p-2 border rounded-md uppercase"
                                value={memoNumber}
                                onChange={handleMemoNumberChange}
                                placeholder="Ej: A123, CORREO, WHATSAPP"
                                required
                                maxLength={10}
                                data-name="memo-number-input"
                            />
                        </div>
                        <div>
                            <label className="block text-gray-700 text-sm font-bold mb-2">
                                Patente
                            </label>
                            <input
                                type="text"
                                className="w-full p-2 border rounded-md uppercase"
                                value={truckPlate}
                                onChange={handleTruckPlateChange}
                                placeholder="Ej: ABCD12"
                                required
                                maxLength={6}
                                data-name="truck-plate-input"
                            />
                        </div>
                        <div>
                            <label className="block text-gray-700 text-sm font-bold mb-2">
                                N° Camión
                                <span className="text-xs text-gray-500 ml-1">(letras y números)</span>
                            </label>
                            <input
                                type="text"
                                className="w-full p-2 border rounded-md uppercase"
                                value={truckNumber}
                                onChange={handleTruckNumberChange}
                                placeholder="Ej: T123"
                                required
                                maxLength={10}
                                data-name="truck-number-input"
                            />
                        </div>
                        <div>
                            <label className="block text-gray-700 text-sm font-bold mb-2">
                                Comuna
                            </label>
                            <select
                                className="w-full p-2 border rounded-md"
                                value={commune}
                                onChange={(e) => setCommune(e.target.value)}
                                required
                                data-name="commune-select"
                            >
                                <option value="">Seleccionar comuna</option>
                                {communes.map((c) => (
                                    <option key={c} value={c}>{c}</option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label className="block text-gray-700 text-sm font-bold mb-2">
                                Fecha Inicio
                            </label>
                            <input
                                type="date"
                                className="w-full p-2 border rounded-md"
                                value={startDate}
                                onChange={(e) => setStartDate(e.target.value)}
                                required
                                data-name="start-date-input"
                            />
                        </div>
                        <div>
                            <label className="block text-gray-700 text-sm font-bold mb-2">
                                Fecha Término
                            </label>
                            <input
                                type="date"
                                className="w-full p-2 border rounded-md"
                                value={endDate}
                                onChange={(e) => setEndDate(e.target.value)}
                                required
                                data-name="end-date-input"
                            />
                        </div>
                        <div className="md:col-span-2">
                            <label className="block text-gray-700 text-sm font-bold mb-2">
                                Observación
                            </label>
                            <textarea
                                className="w-full p-2 border rounded-md"
                                value={observation}
                                onChange={(e) => setObservation(e.target.value)}
                                rows="3"
                                placeholder="Ingrese observaciones adicionales (opcional)"
                                data-name="observation-input"
                            />
                        </div>
                    </div>

                    <div className="flex justify-end space-x-2">
                        <button
                            type="button"
                            onClick={clearForm}
                            className="px-4 py-2 text-gray-600 hover:text-gray-800"
                            data-name="clear-button"
                        >
                            Limpiar
                        </button>
                        <button
                            type="submit"
                            className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 disabled:opacity-50"
                            disabled={loading}
                            data-name="submit-button"
                        >
                            {loading ? (
                                <span>
                                    <i className="fas fa-spinner fa-spin mr-2"></i>
                                    Guardando...
                                </span>
                            ) : (
                                <span>
                                    <i className="fas fa-save mr-2"></i>
                                    Guardar
                                </span>
                            )}
                        </button>
                    </div>
                </form>
            </div>
        );
    } catch (error) {
        console.error('MemoForm error:', error);
        reportError(error);
        return null;
    }
}
