function UserManagement() {
    try {
        const [users, setUsers] = React.useState([]);
        const [username, setUsername] = React.useState('');
        const [password, setPassword] = React.useState('');
        const [error, setError] = React.useState('');

        const loadUsers = async () => {
            try {
                const result = await trickleListObjects('user', 100, true);
                setUsers(result.items.filter(user => !user.objectData.isAdmin));
            } catch (error) {
                console.error('Error loading users:', error);
                setError('Error al cargar usuarios');
            }
        };

        React.useEffect(() => {
            loadUsers();
        }, []);

        const handleCreateUser = async (e) => {
            e.preventDefault();
            try {
                await trickleCreateObject('user', {
                    username,
                    password,
                    isAdmin: false
                });
                setUsername('');
                setPassword('');
                loadUsers();
            } catch (error) {
                console.error('Error creating user:', error);
                setError('Error al crear usuario');
            }
        };

        const handleDeleteUser = async (userId) => {
            if (window.confirm('¿Está seguro de eliminar este usuario?')) {
                try {
                    await trickleDeleteObject('user', userId);
                    loadUsers();
                } catch (error) {
                    console.error('Error deleting user:', error);
                    setError('Error al eliminar usuario');
                }
            }
        };

        return (
            <div className="bg-white p-6 rounded-lg shadow-md" data-name="user-management-container">
                <h2 className="text-xl font-bold mb-4">Gestión de Usuarios</h2>
                {error && (
                    <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                        {error}
                    </div>
                )}
                <form onSubmit={handleCreateUser} className="mb-6" data-name="user-form">
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-gray-700 text-sm font-bold mb-2">
                                Usuario
                            </label>
                            <input
                                type="text"
                                className="w-full p-2 border rounded-md"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                required
                                data-name="username-input"
                            />
                        </div>
                        <div>
                            <label className="block text-gray-700 text-sm font-bold mb-2">
                                Contraseña
                            </label>
                            <input
                                type="password"
                                className="w-full p-2 border rounded-md"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                                data-name="password-input"
                            />
                        </div>
                    </div>
                    <button
                        type="submit"
                        className="mt-4 bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600"
                        data-name="create-user-button"
                    >
                        Crear Usuario
                    </button>
                </form>

                <div className="overflow-x-auto">
                    <table className="min-w-full" data-name="users-table">
                        <thead className="bg-gray-100">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Usuario
                                </th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Acciones
                                </th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {users.map((user) => (
                                <tr key={user.objectId} data-name="user-row">
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        {user.objectData.username}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <button
                                            onClick={() => handleDeleteUser(user.objectId)}
                                            className="text-red-600 hover:text-red-900"
                                            data-name="delete-user-button"
                                        >
                                            <i className="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        );
    } catch (error) {
        console.error('UserManagement error:', error);
        reportError(error);
        return null;
    }
}
