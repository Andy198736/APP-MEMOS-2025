function MemoList({ isAdmin, onNotification }) {
    try {
        const [memos, setMemos] = React.useState([]);
        const [loading, setLoading] = React.useState(true);
        const [error, setError] = React.useState('');
        const [searchTerm, setSearchTerm] = React.useState('');
        const [editingMemo, setEditingMemo] = React.useState(null);
        const [showExpiredOnly, setShowExpiredOnly] = React.useState(false);
        const [refreshing, setRefreshing] = React.useState(false);
        const [expiringToday, setExpiringToday] = React.useState([]);

        const loadMemos = async () => {
            try {
                setLoading(true);
                // Load all memos with a high limit to ensure we get everything
                const allMemos = [];
                let nextPageToken = null;
                
                do {
                    const result = await trickleListObjects('memo', 1000, true, nextPageToken);
                    allMemos.push(...(result.items || []));
                    nextPageToken = result.nextPageToken;
                } while (nextPageToken);

                setMemos(allMemos);

                // Check for memos expiring today
                const today = new Date();
                today.setHours(0, 0, 0, 0);
                const expiring = allMemos.filter(memo => {
                    const endDate = new Date(memo.objectData.endDate);
                    endDate.setHours(0, 0, 0, 0);
                    return endDate.getTime() === today.getTime();
                });
                setExpiringToday(expiring);

                if (expiring.length > 0) {
                    await trickleCreateObject('memo_notification', {
                        type: 'warning',
                        message: `${expiring.length} memorándum(s) vencen hoy`,
                        createdAt: new Date().toISOString()
                    });

                    onNotification({
                        type: 'warning',
                        message: `¡Atención! ${expiring.length} memorándum(s) vencen hoy`
                    });
                }
            } catch (error) {
                console.error('Error loading memos:', error);
                setError('Error al cargar memorándums');
            } finally {
                setLoading(false);
            }
        };

        React.useEffect(() => {
            loadMemos();
            const interval = setInterval(loadMemos, 60000);
            return () => clearInterval(interval);
        }, []);

        const handleRefresh = async () => {
            setRefreshing(true);
            await loadMemos();
            setRefreshing(false);
            onNotification({
                type: 'success',
                message: 'Lista actualizada'
            });
        };

        const filteredMemos = React.useMemo(() => {
            let result = [...memos];

            if (searchTerm) {
                const search = searchTerm.toLowerCase();
                result = result.filter(memo => 
                    memo.objectData.memoNumber?.toLowerCase().includes(search) ||
                    memo.objectData.truckPlate?.toLowerCase().includes(search) ||
                    memo.objectData.truckNumber?.toLowerCase().includes(search) ||
                    memo.objectData.commune?.toLowerCase().includes(search)
                );
            }

            if (showExpiredOnly) {
                const today = new Date();
                today.setHours(0, 0, 0, 0);
                result = result.filter(memo => {
                    const endDate = new Date(memo.objectData.endDate);
                    const userTimezoneOffset = endDate.getTimezoneOffset() * 60000;
                    const adjustedEndDate = new Date(endDate.getTime() + userTimezoneOffset);
                    adjustedEndDate.setHours(0, 0, 0, 0);
                    return adjustedEndDate < today;
                });
            }

            return result;
        }, [memos, searchTerm, showExpiredOnly]);

        const handleDelete = async (memoId) => {
            if (window.confirm('¿Está seguro de eliminar este memorándum?')) {
                try {
                    await trickleDeleteObject('memo', memoId);
                    loadMemos();
                    onNotification({
                        type: 'success',
                        message: 'Memorándum eliminado exitosamente'
                    });
                } catch (error) {
                    console.error('Delete error:', error);
                    onNotification({
                        type: 'error',
                        message: 'Error al eliminar memorándum'
                    });
                }
            }
        };

        const handleExport = () => {
            try {
                if (!filteredMemos || filteredMemos.length === 0) {
                    onNotification({
                        type: 'warning',
                        message: 'No hay datos para exportar'
                    });
                    return;
                }

                const dataToExport = filteredMemos.map(memo => ({
                    'N° Memo': memo.objectData.memoNumber || '',
                    'Patente': memo.objectData.truckPlate || '',
                    'N° Camión': memo.objectData.truckNumber || '',
                    'Comuna': memo.objectData.commune || '',
                    'Fecha Inicio': formatDate(memo.objectData.startDate) || '',
                    'Fecha Término': formatDate(memo.objectData.endDate) || '',
                    'Estado': getMemoStatus(memo.objectData.endDate).text || '',
                    'Observación': memo.objectData.observation || ''
                }));

                const fileName = `memorandums_${new Date().toISOString().split('T')[0]}`;
                downloadExcel(dataToExport, fileName);
                onNotification({
                    type: 'success',
                    message: 'Datos exportados exitosamente'
                });
            } catch (error) {
                console.error('Export error:', error);
                onNotification({
                    type: 'error',
                    message: 'Error al exportar datos'
                });
            }
        };

        if (loading) {
            return (
                <div className="flex justify-center items-center p-4">
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Cargando...
                </div>
            );
        }

        return (
            <div className="space-y-6" data-name="memo-container">
                {expiringToday.length > 0 && (
                    <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4" data-name="expiring-today-alert">
                        <div className="flex items-center">
                            <div className="flex-shrink-0">
                                <i className="fas fa-exclamation-triangle text-yellow-400"></i>
                            </div>
                            <div className="ml-3">
                                <p className="text-sm text-yellow-700">
                                    <span className="font-bold">¡Atención! Memorándums que vencen hoy:</span>
                                </p>
                                <div className="mt-2 space-y-1">
                                    {expiringToday.map(memo => (
                                        <p key={memo.objectId} className="text-sm text-yellow-700">
                                            • Memo N° {memo.objectData.memoNumber} - Patente: {memo.objectData.truckPlate}
                                        </p>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                <div className="bg-white rounded-lg shadow-md" data-name="memo-list-container">
                    <div className="p-6">
                        <div className="flex justify-between items-center mb-4">
                            <div className="flex items-center">
                                <i className="fas fa-truck text-blue-500 text-2xl mr-3"></i>
                                <h2 className="text-xl font-bold">Lista de Memorándums</h2>
                                <button
                                    onClick={handleRefresh}
                                    className={`ml-3 p-2 text-gray-600 hover:text-gray-900 ${refreshing ? 'animate-spin' : ''}`}
                                    disabled={refreshing}
                                    title="Actualizar lista"
                                >
                                    <i className="fas fa-sync-alt"></i>
                                </button>
                            </div>
                            <div className="flex items-center gap-4">
                                <input
                                    type="text"
                                    placeholder="Buscar..."
                                    className="p-2 border rounded-md"
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                />
                                <button
                                    onClick={() => setShowExpiredOnly(!showExpiredOnly)}
                                    className={`px-4 py-2 rounded-md ${
                                        showExpiredOnly 
                                            ? 'bg-blue-500 text-white hover:bg-blue-600' 
                                            : 'bg-red-500 text-white hover:bg-red-600'
                                    }`}
                                >
                                    {showExpiredOnly ? 'Mostrar Todos' : 'Ver Vencidos'}
                                </button>
                                <button
                                    onClick={handleExport}
                                    className="bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600"
                                >
                                    <i className="fas fa-file-export mr-2"></i>
                                    Exportar
                                </button>
                            </div>
                        </div>

                        {error && (
                            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                                {error}
                            </div>
                        )}

                        <div className="overflow-x-auto">
                            <table className="min-w-full divide-y divide-gray-200">
                                <thead className="bg-gray-50">
                                    <tr>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            N° Memo
                                        </th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Patente
                                        </th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            N° Camión
                                        </th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Comuna
                                        </th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Fecha Inicio
                                        </th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Fecha Término
                                        </th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Estado
                                        </th>
                                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Observación
                                        </th>
                                        {isAdmin && (
                                            <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                Acciones
                                            </th>
                                        )}
                                    </tr>
                                </thead>
                                <tbody className="bg-white divide-y divide-gray-200">
                                    {filteredMemos.map((memo) => {
                                        const status = getMemoStatus(memo.objectData.endDate);
                                        return (
                                            <tr key={memo.objectId}>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    {memo.objectData.memoNumber}
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    {memo.objectData.truckPlate}
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    {memo.objectData.truckNumber}
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    {memo.objectData.commune}
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    {formatDate(memo.objectData.startDate)}
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    {formatDate(memo.objectData.endDate)}
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${status.color}`}>
                                                        {status.text}
                                                    </span>
                                                </td>
                                                <td className="px-6 py-4">
                                                    {memo.objectData.observation || 
                                                        <span className="text-gray-400">Sin observaciones</span>
                                                    }
                                                </td>
                                                {isAdmin && (
                                                    <td className="px-6 py-4 whitespace-nowrap text-right">
                                                        <div className="flex space-x-2 justify-end">
                                                            <button
                                                                onClick={() => setEditingMemo(memo)}
                                                                className="text-indigo-600 hover:text-indigo-900"
                                                            >
                                                                <i className="fas fa-edit"></i>
                                                            </button>
                                                            <button
                                                                onClick={() => handleDelete(memo.objectId)}
                                                                className="text-red-600 hover:text-red-900"
                                                            >
                                                                <i className="fas fa-trash"></i>
                                                            </button>
                                                        </div>
                                                    </td>
                                                )}
                                            </tr>
                                        );
                                    })}
                                    {filteredMemos.length === 0 && (
                                        <tr>
                                            <td colSpan={isAdmin ? 9 : 8} className="px-6 py-4 text-center text-gray-500">
                                                No hay memorándums para mostrar
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        );
    } catch (error) {
        console.error('MemoList error:', error);
        reportError(error);
        return null;
    }
}
