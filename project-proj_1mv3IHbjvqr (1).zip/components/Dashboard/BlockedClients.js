function BlockedClients({ isAdmin }) {
    try {
        const [clients, setClients] = React.useState([]);
        const [newClient, setNewClient] = React.useState('');
        const [loading, setLoading] = React.useState(true);
        const [error, setError] = React.useState('');

        const loadClients = async () => {
            try {
                setLoading(true);
                const result = await trickleListObjects('blocked_client', 100, true);
                const sortedClients = result.items || [];
                setClients(sortedClients);
            } catch (error) {
                console.error('Error loading blocked clients:', error);
                setError('Error al cargar clientes bloqueados');
            } finally {
                setLoading(false);
            }
        };

        React.useEffect(() => {
            loadClients();
            // Set up interval to check for updates
            const interval = setInterval(loadClients, 30000);
            return () => clearInterval(interval);
        }, []);

        const handleAddClient = async (e) => {
            e.preventDefault();
            if (!newClient.trim()) return;

            try {
                await trickleCreateObject('blocked_client', {
                    name: newClient.trim().toUpperCase(),
                    createdAt: new Date().toISOString()
                });
                setNewClient('');
                loadClients();
            } catch (error) {
                console.error('Error adding blocked client:', error);
                setError('Error al agregar cliente bloqueado');
            }
        };

        const handleDeleteClient = async (clientId) => {
            if (window.confirm('¿Está seguro de eliminar este cliente de la lista negra?')) {
                try {
                    await trickleDeleteObject('blocked_client', clientId);
                    loadClients();
                } catch (error) {
                    console.error('Error deleting blocked client:', error);
                    setError('Error al eliminar cliente bloqueado');
                }
            }
        };

        if (loading) {
            return (
                <div className="flex justify-center items-center py-4">
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Cargando...
                </div>
            );
        }

        return (
            <div className="bg-white p-6 rounded-lg shadow-md" data-name="blocked-clients-container">
                <div className="flex items-center mb-6">
                    <div className="text-red-600 text-2xl mr-3">
                        <i className="fas fa-ban"></i>
                    </div>
                    <h2 className="text-xl font-semibold">Clientes Bloqueados</h2>
                </div>

                {error && (
                    <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                        {error}
                    </div>
                )}

                {isAdmin && (
                    <form onSubmit={handleAddClient} className="mb-6">
                        <div className="flex gap-2">
                            <input
                                type="text"
                                className="flex-1 p-2 border rounded-md uppercase"
                                placeholder="Nombre del cliente"
                                value={newClient}
                                onChange={(e) => setNewClient(e.target.value)}
                                data-name="new-client-input"
                            />
                            <button
                                type="submit"
                                className="bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600"
                                data-name="add-client-button"
                            >
                                <i className="fas fa-plus mr-2"></i>
                                Agregar
                            </button>
                        </div>
                    </form>
                )}

                <div className="overflow-hidden rounded-lg border">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                    Cliente
                                </th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                    Fecha de Bloqueo
                                </th>
                                {isAdmin && (
                                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                                        Acciones
                                    </th>
                                )}
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {clients.map((client) => (
                                <tr key={client.objectId}>
                                    <td className="px-6 py-4 whitespace-nowrap font-medium">
                                        {client.objectData.name}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        {formatDate(client.objectData.createdAt)}
                                    </td>
                                    {isAdmin && (
                                        <td className="px-6 py-4 whitespace-nowrap text-right">
                                            <button
                                                onClick={() => handleDeleteClient(client.objectId)}
                                                className="text-red-600 hover:text-red-900"
                                                data-name="delete-client-button"
                                            >
                                                <i className="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    )}
                                </tr>
                            ))}
                            {clients.length === 0 && (
                                <tr>
                                    <td colSpan={isAdmin ? 3 : 2} className="px-6 py-4 text-center text-gray-500">
                                        No hay clientes bloqueados
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        );
    } catch (error) {
        console.error('BlockedClients error:', error);
        reportError(error);
        return null;
    }
}
