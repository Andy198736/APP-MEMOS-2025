function Clock() {
    try {
        const [time, setTime] = React.useState(new Date());

        React.useEffect(() => {
            const timer = setInterval(() => {
                setTime(new Date());
            }, 1000);

            return () => clearInterval(timer);
        }, []);

        const formatTime = (date) => {
            return date.toLocaleTimeString('es-CL', {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: false
            });
        };

        const formatDate = (date) => {
            return date.toLocaleDateString('es-CL', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
        };

        return (
            <div className="text-center" data-name="clock">
                <div className="text-xl font-bold text-gray-800">
                    {formatTime(time)}
                </div>
                <div className="text-sm text-gray-600 capitalize">
                    {formatDate(time)}
                </div>
            </div>
        );
    } catch (error) {
        console.error('Clock error:', error);
        reportError(error);
        return null;
    }
}
