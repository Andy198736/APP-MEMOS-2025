function Navbar({ user, onLogout }) {
    try {
        return (
            <nav className="bg-gray-800 text-white p-4" data-name="navbar">
                <div className="container mx-auto flex justify-between items-center">
                    <div className="text-xl font-bold" data-name="navbar-brand">
                        Sistema de Memorandums
                    </div>
                    <Clock />
                    <div className="flex items-center gap-4">
                        <span data-name="user-info">
                            <i className="fas fa-user mr-2"></i>
                            {user.objectData.username}
                        </span>
                        <button
                            onClick={onLogout}
                            className="bg-red-500 text-white py-2 px-4 rounded hover:bg-red-600"
                            data-name="logout-button"
                        >
                            <i className="fas fa-sign-out-alt mr-2"></i>
                            Cerrar Sesión
                        </button>
                    </div>
                </div>
            </nav>
        );
    } catch (error) {
        console.error('Navbar error:', error);
        reportError(error);
        return null;
    }
}
