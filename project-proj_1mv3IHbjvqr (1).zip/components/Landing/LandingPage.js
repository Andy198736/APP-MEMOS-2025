function LandingPage({ onStartClick }) {
    try {
        return (
            <div className="landing-container" data-name="landing-container">
                <div className="landing-header" data-name="landing-header">
                    <div className="landing-logo" data-name="landing-logo">
                        <i className="fas fa-truck-moving text-5xl text-blue-600"></i>
                    </div>
                    <h1 className="landing-title" data-name="landing-title">
                        Sistema de Memorandums
                    </h1>
                    <p className="landing-subtitle" data-name="landing-subtitle">
                        Gestión de autorizaciones para camiones
                    </p>
                </div>

                <div className="landing-features" data-name="landing-features">
                    <div className="landing-feature" data-name="landing-feature">
                        <i className="fas fa-file-alt text-3xl text-blue-500"></i>
                        <h3>Gestión de Memorandums</h3>
                        <p>Control y seguimiento de autorizaciones</p>
                    </div>
                    <div className="landing-feature" data-name="landing-feature">
                        <i className="fas fa-clock text-3xl text-blue-500"></i>
                        <h3>Alertas de Vencimiento</h3>
                        <p>Notificaciones automáticas de expiración</p>
                    </div>
                    <div className="landing-feature" data-name="landing-feature">
                        <i className="fas fa-users text-3xl text-blue-500"></i>
                        <h3>Múltiples Usuarios</h3>
                        <p>Gestión de accesos y permisos</p>
                    </div>
                    <div className="landing-feature" data-name="landing-feature">
                        <i className="fas fa-file-export text-3xl text-blue-500"></i>
                        <h3>Exportación de Datos</h3>
                        <p>Reportes en formato Excel</p>
                    </div>
                </div>

                <div className="landing-cta" data-name="landing-cta">
                    <button
                        onClick={onStartClick}
                        className="landing-button"
                        data-name="start-button"
                    >
                        Iniciar Sesión
                        <i className="fas fa-arrow-right ml-2"></i>
                    </button>
                </div>

                <footer className="landing-footer" data-name="landing-footer">
                    <p>&copy; 2024 Sistema de Memorandums. Todos los derechos reservados.</p>
                </footer>
            </div>
        );
    } catch (error) {
        console.error('LandingPage error:', error);
        reportError(error);
        return null;
    }
}
