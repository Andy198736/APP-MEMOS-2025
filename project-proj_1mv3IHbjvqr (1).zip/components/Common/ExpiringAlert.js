function ExpiringAlert({ memos }) {
    try {
        const [isExpanded, setIsExpanded] = React.useState(false);
        const [isVisible, setIsVisible] = React.useState(true);

        if (!memos || memos.length === 0 || !isVisible) return null;

        return (
            <div className="fixed bottom-4 right-4 bg-yellow-50 border-l-4 border-yellow-400 rounded shadow-lg z-50" 
                style={{ maxWidth: '300px' }}
                data-name="expiring-alert"
            >
                <div className="relative">
                    <button 
                        onClick={() => setIsVisible(false)}
                        className="absolute top-2 right-2 text-gray-500 hover:text-gray-700"
                        title="Cerrar notificación"
                        data-name="close-alert"
                    >
                        <i className="fas fa-times"></i>
                    </button>

                    <div className="p-3 cursor-pointer" onClick={() => setIsExpanded(!isExpanded)}>
                        <div className="flex items-center">
                            <div className="flex-shrink-0">
                                <i className="fas fa-exclamation-triangle text-yellow-400 text-sm animate-pulse"></i>
                            </div>
                            <div className="ml-2 flex-grow">
                                <p className="text-sm text-yellow-700 font-medium">
                                    {memos.length} memo{memos.length > 1 ? 's' : ''} vence{memos.length > 1 ? 'n' : ''} hoy
                                </p>
                            </div>
                            <div className="ml-2">
                                <i className={`fas fa-chevron-${isExpanded ? 'up' : 'down'} text-yellow-400 text-xs`}></i>
                            </div>
                        </div>
                    </div>

                    {isExpanded && (
                        <div className="px-3 pb-3 border-t border-yellow-200">
                            <div className="mt-2 space-y-1">
                                {memos.map(memo => (
                                    <p key={memo.objectId} className="text-xs text-yellow-700">
                                        • {memo.objectData.memoNumber} - {memo.objectData.truckPlate}
                                    </p>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            </div>
        );
    } catch (error) {
        console.error('ExpiringAlert error:', error);
        reportError(error);
        return null;
    }
}
