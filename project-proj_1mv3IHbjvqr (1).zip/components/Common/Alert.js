function Alert({ type = 'info', message, onClose }) {
    try {
        if (!message) return null;

        const alertClasses = {
            success: 'bg-green-100 border-green-400 text-green-700',
            error: 'bg-red-100 border-red-400 text-red-700',
            warning: 'bg-yellow-100 border-yellow-400 text-yellow-700',
            info: 'bg-blue-100 border-blue-400 text-blue-700'
        };

        const iconClasses = {
            success: 'fas fa-check-circle',
            error: 'fas fa-exclamation-circle',
            warning: 'fas fa-exclamation-triangle',
            info: 'fas fa-info-circle'
        };

        return (
            <div 
                className={`border px-4 py-3 rounded relative flex items-center ${alertClasses[type]}`}
                role="alert"
                data-name="alert"
            >
                <i className={`${iconClasses[type]} mr-2`}></i>
                <span className="block sm:inline">{message}</span>
                {onClose && (
                    <button
                        className="absolute top-0 bottom-0 right-0 px-4 py-3"
                        onClick={onClose}
                        data-name="alert-close-button"
                    >
                        <i className="fas fa-times"></i>
                    </button>
                )}
            </div>
        );
    } catch (error) {
        console.error('Alert error:', error);
        reportError(error);
        return null;
    }
}
